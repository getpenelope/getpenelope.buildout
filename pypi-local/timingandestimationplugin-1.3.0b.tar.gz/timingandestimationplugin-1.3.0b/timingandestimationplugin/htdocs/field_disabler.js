(function(){
   var x = document.getElementById('totalhours');
   if(x){
      x.disabled=true;
   }
})()
