This plugin provides a means of maintaining News for a channel.  It was
partially inspired by the news system used on #debian's bot.
