This is a simple plugin to allow querying dictionaries for word
definitions.

In order to use this plugin you must have the following modules
installed:
- dictclient: http://quux.org:70/devel/dictclient
