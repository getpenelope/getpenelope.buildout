This plugin ensures that the bot won't say any words the bot owner finds
offensive.  As an additional capability, it can (optionally) kick users who
use such words from channels that have that capability enabled.
