This is a simple plugin to provide access to the Google services we all know
and love from our favorite IRC bot.
