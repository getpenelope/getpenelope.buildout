"""moved to L{openid.extensions.sreg}"""

import warnings
warnings.warn("openid.sreg has moved to openid.extensions.sreg",
              DeprecationWarning)

from openid.extensions.sreg import *
