penelope.core
=============

penelope.core details.


[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/40ad7f5979085f8c8939c9b9b6e4101d "githalytics.com")](http://githalytics.com/getpenelope/por.dashboard)
