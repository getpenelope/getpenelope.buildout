
__version__ = __import__('pkg_resources').get_distribution(
                                        'TracCustomFieldAdmin').version
