from setuptools import setup

version = '0.1.2'


def file_content(filename):
    f = open(filename)
    s = [x.rstrip() for x in f if x.strip() != ';-*-rst-*-']
    f.close()
    return '\n'.join(s)

readme = file_content('README.txt')
history = file_content('HISTORY.txt')

sql_requires = [
    'SQLAlchemy >= 0.4.7',
    ]

trac_requires = sql_requires + [
    'Trac >= 0.11',
    'simplejson >= 1.9.2',
    ]

setup(name='ClueTimer',
      version=version,
      description="Module for tracking time.",
      long_description=readme + "\n" + history,
      keywords='',
      author='Rocky Burt',
      author_email='rocky@serverzen.com',
      url='http://www.cluemapper.org',
      license='BSD',
      packages=['cluetimer', 'cluetimer.web', 'cluetimer.tracsupport'],
      package_dir={'': 'src'},
      include_package_data=True,
      zip_safe=False,
      test_suite="cluetimer.tests.test_suite",
      install_requires=[
          'WebOb >= 0.9.1, <= 0.9.9999',
      ],
      extras_require = {
          'sql': sql_requires,
          'trac': trac_requires,
          },

      entry_points={
          'console_scripts': [
              'cluetimer = cluetimer.app:main',
              ],
          'trac.plugins': [
              'ClueTimer = cluetimer.tracsupport',
              ],
          },
      )
