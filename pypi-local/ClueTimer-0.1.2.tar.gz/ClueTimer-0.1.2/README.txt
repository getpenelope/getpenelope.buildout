.. -*-rst-*-

=========
ClueTimer
=========

Overview
========

ClueTimer is a timing application built as a wsgi application.  In
it's current form it's mostly only useful as a Trac plugin.  It heavily
relies on Dojo to provide AJAX-style functionality.

Dependencies
============

  * (required) Python 2.5+

Installation
============

ClueTimer was designed tobe installed using standard ``easy_install`` methods.
A simple ``easy_install ClueTimer`` should suffice.  This should generate a new
script called ``cluetimer``.

Credits
=======

  * Rocky Burt (maintainer) - rocky AT serverzen DOT com
