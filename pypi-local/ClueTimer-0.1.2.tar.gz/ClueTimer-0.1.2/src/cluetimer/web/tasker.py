from django import http
from django import newforms as forms
from django.shortcuts import render_to_response
from cluetimer.web import utils


class AddTaskForm(forms.Form):
    userid = forms.CharField(max_length = 100, required = True)
    name = forms.CharField(max_length = 100, required = True)
    summary = forms.CharField(max_length = 1000,
                              required = False,
                              widget=forms.widgets.Textarea())

    def save(self):
        taskm = utils.get_task_manager()
        taskm.add_task(self.clean_data['userid'],
                       self.clean_data['name'],
                       self.clean_data['summary'])


def index(request):
    if request.method == 'POST':
        if request.POST.get('create_task', False):
            addform = AddTaskForm(request.POST)
            if addform.is_valid():
                addform.save()
                return http.HttpResponseRedirect('.')
    else:
        addform = AddTaskForm()

    taskm = utils.get_task_manager()
    return render_to_response('tasks.html', {'addform': str(addform),
                                             'tasks': taskm.get_tasks()})
