from django.conf.urls.defaults import patterns

urlpatterns = patterns('',
    (r'^tasks/', 'cluetimer.web.tasker.index'),
    (r'^time/', 'cluetimer.web.timer.index'),
)
