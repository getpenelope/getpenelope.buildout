from cluetimer import tasker
from cluetimer import timer
from cluetimer.web import settings


def importattr(fullname):
    """Retrieve the attribute identified by *fullname* by importing
    appopriate modules and accessing the attribute.

      >>> importattr('sys')
      <module 'sys' ...>

      >>> importattr('os.path.join')
      <function join ...>

      >>> importattr('os.environ')
      {...}
    """

    left = fullname.split('.')
    if len(left) == 1:
        return __import__(fullname)

    attrname = left[-1]
    left = left[:-1]
    if len(left) == 1:
        importargs = left
    else:
        mname = left[-1]
        package = left[:-1][0]
        importargs = [package+'.'+mname, locals(), globals(), [package]]

    m = __import__(*importargs)
    f = getattr(m, attrname)
    return f


class ManagerKeeper(object):

    def __init__(self):
        self._taskmanager = None
        self._timemanager = None

    def get_task_manager(self):
        if self._taskmanager is not None:
            return self._taskmanager
        ds_factory = importattr(settings.TASK_DATASTORE)
        ds = ds_factory(*settings.TASK_DATASTORE_ARGS)
        self._taskmanager = tasker.TaskManager(ds)
        return self._taskmanager

    def get_time_manager(self):
        if self._timemanager is not None:
            return self._timemanager
        ds_factory = importattr(settings.TIME_DATASTORE)
        ds = ds_factory(*settings.TIME_DATASTORE_ARGS)
        self._timemanager = timer.TimeManager(ds)
        return self._timemanager

_keeper = ManagerKeeper()
get_task_manager = _keeper.get_task_manager
get_time_manager = _keeper.get_time_manager
