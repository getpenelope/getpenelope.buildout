from django import http
from django import newforms as forms
from django.shortcuts import render_to_response as render
from cluetimer.web import utils


class AddTimeForm(forms.Form):
    userid = forms.CharField(max_length = 100, required = True)
    date = forms.DateField(required = True)
    name = forms.CharField(max_length = 100, required = True)
    hours = forms.IntegerField(required = True)
    taskid = forms.CharField(required = True)
    summary = forms.CharField(max_length = 1000,
                              required = False,
                              widget=forms.widgets.Textarea())

    def save(self):
        timem = utils.get_time_manager()
        timem.add_interval(self.clean_data['userid'],
                           self.clean_data['date'],
                           self.clean_data['hours'],
                           self.clean_data['taskid'],
                           self.clean_data['summary'])


def index(request):
    if request.method == 'POST':
        if request.POST.get('create_time', False):
            addform = AddTimeForm(request.POST)
            if addform.is_valid():
                addform.save()
                return http.HttpResponseRedirect('.')
    else:
        addform = AddTimeForm()

    timem = utils.get_time_manager()
    return render('time.html', {'addform': str(addform),
                                'intervals': timem.get_intervals()})
