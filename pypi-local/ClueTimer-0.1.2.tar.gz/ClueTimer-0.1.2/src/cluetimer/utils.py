import logging
import os

_LOGGER = None


def setup_logger():
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER

    formatter = logging.Formatter('%(asctime)s %(levelname)-5.5s '
                                  '[%(name)s] %(message)s')
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    handler.setLevel(logging.DEBUG)
    logger = logging.getLogger('cluetimer')
    logger.addHandler(handler)
    logger.setLevel(int(os.environ.get('cluetimer.loglevel', logging.INFO)))

    _LOGGER = logger

    return _LOGGER
