import unittest
import doctest


def test_suite():
    flags = doctest.ELLIPSIS
    suite = unittest.TestSuite()
    return unittest.TestSuite(
        (doctest.DocTestSuite('cluetimer.tasker',
                              optionflags=flags),
         doctest.DocTestSuite('cluetimer.timer',
                              optionflags=flags),
         doctest.DocTestSuite('cluetimer.tracsupport',
                              optionflags=flags),
         ))


def main():
    runner = unittest.TextTestRunner()
    runner.run(test_suite())


if __name__ == '__main__':
    main()
