import datetime
import sqlalchemy as sa
from sqlalchemy import orm
from cluetimer import tasker
from cluetimer import timer

metadata = sa.MetaData()


class SqlTask(tasker.Task):
    pass

task_table = sa.Table('tasks', metadata,
                      sa.Column('taskid', sa.Integer, primary_key=True),
                      sa.Column('userid', sa.Unicode(20)),
                      sa.Column('name', sa.Unicode(100)),
                      sa.Column('summary', sa.Unicode(1000)),
                      sa.Column('estimate', sa.Float))

orm.mapper(SqlTask, task_table)


class SqlInterval(timer.Interval):
    pass

interval_table = sa.Table('time_logged', metadata,
                          sa.Column('intervalid', sa.Integer,
                                    primary_key=True),
                          sa.Column('date', sa.Date, nullable=False),
                          sa.Column('userid', sa.Unicode(20)),
                          sa.Column('hours', sa.Integer),
                          sa.Column('taskid', sa.String(20)),
                          sa.Column('summary', sa.Unicode(1000)))

orm.mapper(SqlInterval, interval_table)


class BaseSqlDataStore(object):

    def __init__(self, url=None, engine=None, bootstrap=False):
        assert url is not None or engine is not None, \
               'Must specify either url or engine'
        self._url = url
        self._engine = engine
        if bootstrap:
            self.bootstrap_data()

    @property
    def engine(self):
        engine = getattr(self, '_engine', None)
        if engine is not None:
            return engine
        self._engine = sa.create_engine(self._url)
        return self._engine

    @property
    def _session_factory(self):
        session_factory = getattr(self, '_cached_session_factory', None)
        if session_factory is None:
            maker = orm.sessionmaker(bind=self.engine,
                                     autoflush=True,
                                     transactional=True)
            session_factory = orm.scoped_session(maker)
            self._cached_session_factory = session_factory
        return session_factory

    def _gen_session(self):
        return self._session_factory()

    def bootstrap_data(self):
        raise NotImplementedError()


class SqlTaskDataStore(BaseSqlDataStore, tasker.TaskDataStore):

    task_factory = SqlTask

    def save_task(self, t):
        session = self._gen_session()
        session.save_or_update(t)
        session.commit()

    def load_task(self, taskid):
        session = self._gen_session()
        return session.query(SqlTask).filter(SqlTask.taskid==taskid).one()

    def load_tasks(self, userid=None):
        session = self._gen_session()
        res = session.query(SqlTask)
        if userid:
            res = res.filter_by(userid=userid)
        return res

    def bootstrap_data(self):
        t = metadata.tables['tasks']
        if not t.exists(bind=self.engine):
            t.create(bind=self.engine)


class SqlIntervalDataStore(BaseSqlDataStore, timer.IntervalDataStore):

    interval_factory = SqlInterval

    def save_interval(self, interval):
        session = self._gen_session()
        if interval in session:
            session.expunge(interval)
        if interval.date is None:
            interval.date = datetime.date.today()
        if isinstance(interval.userid, str):
            interval.userid = interval.userid.decode('utf-8')
        session.save_or_update(interval)
        session.commit()

    def del_interval(self, interval):
        if isinstance(interval, basestring) or isinstance(interval, int):
            interval = self.load_interval(interval)
        ses = self._gen_session()
        ses.delete(interval)
        ses.commit()

    def load_intervals(self, startdate=None, enddate=None, userid=None,
                       taskid=None):
        res = self._gen_session().query(SqlInterval)
        if startdate is not None:
            res = res.filter(SqlInterval.date>=startdate)
        if enddate is not None:
            res = res.filter(SqlInterval.date<=enddate)
        if userid:
            if isinstance(userid, str):
                userid = userid.decode('utf-8')
            res = res.filter(SqlInterval.userid==userid)
        if taskid:
            res = res.filter(SqlInterval.taskid==taskid)

        return res

    def load_interval(self, intervalid):
        q = self._gen_session().query(SqlInterval)
        return q.filter(SqlInterval.intervalid==intervalid).one()

    def bootstrap_data(self):
        t = metadata.tables['time_logged']
        if not t.exists(bind=self.engine):
            t.create(bind=self.engine)
