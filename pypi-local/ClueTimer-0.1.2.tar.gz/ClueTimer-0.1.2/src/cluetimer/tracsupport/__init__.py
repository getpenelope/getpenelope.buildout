import os
import calendar
import datetime
import simplejson
from pkg_resources import resource_filename
from trac import core as traccore
from trac import env as tracenv
from trac.db import api as dbapi
from trac.web import api
from trac.web import chrome
from genshi.builder import tag as builder

from cluetimer import timer
from cluetimer import sqlmodel
from cluetimer.tracsupport import utils

TICKET_CUSTOM = 'ticket-custom'

ONE_DAY = datetime.timedelta(days=1)
_marker = object()


class TimeTrackingSetup(traccore.Component):
    """Templates and resources for all ClueTimer plugins."""

    traccore.implements(chrome.ITemplateProvider,
                        tracenv.IEnvironmentSetupParticipant)

    def __init__(self, *args, **kwargs):
        traccore.Component.__init__(self, *args, **kwargs)

        tracdburi = dbapi.DatabaseManager(self.env).connection_uri
        dbtype, dbextra = tracdburi.split(':', 1)
        if dbtype == 'sqlite':
            dbpath = p = os.path.join(self.env.path, dbextra)
            url = 'sqlite:///' + dbpath
            self.sqldatastore = sqlmodel.SqlIntervalDataStore(url)
        else:
            raise NotImplementedError("Can only connect to sqlite db's at "
                                      "this time")

        # TODO: switch to a sqlalchemy engine that deals better with Trac
        # The current state for sqlalchemy+trac+sqlite is that the connection
        # that trac provides has detect_types=sqlite.PARSE_DECLTYPES set.
        # That setting has pysqlite return datetime.date objects for DATE's
        # and SQLAlchemy expects to get the default unicode string values
        # back for DATE's instead.
        # - Rocky
        #datastore = sqlmodel.SqlIntervalDataStore(engine=sa.engine(self.env))

        self.timemanager = timer.TimeManager(self.sqldatastore)

    def environment_created(self):
        if self.environment_needs_upgrade(None):
            self.upgrade_environment(None)

    def environment_needs_upgrade(self, db):
        for table_name in ['time_logged']:
            table = sqlmodel.metadata.tables[table_name]
            if not table.exists(bind=self.sqldatastore.engine):
                return True

        if not self.config.get(TICKET_CUSTOM, 'estimatedhours', None):
            return True

        return False

    def upgrade_environment(self, db):
        self.sqldatastore.bootstrap_data()

        self.config.set(TICKET_CUSTOM, 'estimatedhours', 'text')
        self.config.set(TICKET_CUSTOM, 'estimatedhours.value', '0')
        if not self.config.get(TICKET_CUSTOM, 'estimatedhours.order'):
            self.config.set(TICKET_CUSTOM, 'estimatedhours.order', '1')
        self.config.set(TICKET_CUSTOM, 'estimatedhours.label',
                        'Estimated Number of Hours')

        self.config.save()

    def get_htdocs_dirs(self):
        return [('timetracking', resource_filename(__name__, 'htdocs'))]

    def get_templates_dirs(self):
        return [resource_filename(__name__, 'templates')]


class TimeTracking(traccore.Component):
    """Adds the necessary timetracking js and css to appropriate requests.
    """

    traccore.implements(api.IRequestFilter)

    def __init__(self, *args, **kwargs):
        traccore.Component.__init__(self, *args, **kwargs)
        self.timemanager = TimeTrackingSetup(self.env).timemanager

    def pre_process_request(self, req, handler):
        # we only load this up if we're on a ticket view
        ticket_info = [x for x in req.path_info.split('/') if x.strip()]
        if len(ticket_info) < 2 or ticket_info[0] != 'ticket':
            return handler

        utils.add_script(req, 'timetracking/pre-dojo.js')
        setup_cluetimer_resources(req)
        utils.add_script(req, 'timetracking/enable-timelogging.js')
        return handler

    def post_process_request(self, req, template, data, content_type):
        return (template, data, content_type)


def setup_cluetimer_resources(req):
    # dojo
    cnd_base = 'http://ajax.googleapis.com/ajax/libs/dojo/1.5/'
    utils.add_script(req, cnd_base+'dojo/dojo.xd.js')
    utils.add_stylesheet(req, cnd_base+'dijit/themes/claro/claro.css')

    # cluetimer
    utils.add_stylesheet(req, 'timetracking/trac-cluetimer.css')
    utils.add_script(req, 'timetracking/cluetimer.js')
    utils.add_script(req, 'timetracking/trac.js')
    utils.add_script(req, 'timetracking/timebox.js')
    utils.add_script(req, 'timetracking/reporting.js')


def sameday(d1, d2):
    return d1.year == d2.year and d1.month == d2.month and d1.day == d2.day


def date_to_json(somedate):
    """Convert date to nice string.

      >>> from datetime import date
      >>> date_to_json(date(2008, 03, 07))
      '2008-03-07'
    """

    return '%04d-%02d-%02d' % (somedate.year, somedate.month, somedate.day)


def build_date(somedate):
    if isinstance(somedate, basestring):
        year, month, day = somedate.split('-')
        somedate = datetime.date(int(year), int(month), int(day))
    else:
        somedate = datetime.datetime(somedate.year, somedate.month,
                                     somedate.day)
    return somedate


def interval_cmp(x, y):
    return cmp((int(x.taskid), x.date), (int(y.taskid), y.date))


class JsonTimeTracking(traccore.Component):
    """JSON-RPC endpoint for trac time tracking

      >>> class Mock(object):
      ...     def __init__(self, **kw):
      ...         self.__dict__.update(kw)
      >>> json = JsonTimeTracking(Mock(components={},
      ...                              component_activated=lambda x: False))
      >>> json._cached_setup = Mock(timemanager=Mock(get_total_time=lambda userid, startdate, enddate: 0))
      >>> len(json.json_report_week(Mock(authname='foo'))['days'])
      7
    """

    traccore.implements(api.IRequestHandler)

    @property
    def setup(self):
        if hasattr(self, '_cached_setup'):
            return self._cached_setup
        self._cached_setup = TimeTrackingSetup(self.env)
        return self._cached_setup

    @property
    def timemanager(self):
        return self.setup.timemanager

    def process_request(self, req):
        json = simplejson.loads(req.read())
        method = json['method']
        params = json['params']
        id = json['id']

        try:
            method = getattr(self, 'json_'+method)
            result = method(req, *params)
            raw = simplejson.dumps(dict(result=result,
                                        error=None,
                                        id=id))
        except Exception, err:
            self.log.exception('Error while handling request')
            raw = simplejson.dumps(dict(result=None,
                                        error=str(err),
                                        id=id))

        req.send(raw, 'application/json')

    def match_request(self, req):
        if req.path_info.endswith('/json_timetracking'):
            return True
        return False

    def json_updatebooking(self, req, intervalid, hours=_marker,
                           summary=_marker):
        kw = {}

        if hours is not _marker:
            kw['hours'] = hours
        if summary is not _marker:
            kw['summary'] = summary

        if kw:
            self.timemanager.update_interval(intervalid, **kw)

    def json_updatebooking_hours(self, req, intervalid, hours):
        self.json_updatebooking(req, intervalid, hours=hours)

    def json_updatebooking_summary(self, req, intervalid, summary):
        self.json_updatebooking(req, intervalid, summary=summary)

    def json_delete_booking(self, req, intervalid):
        self.timemanager.remove_interval(intervalid)

    def json_postbooking(self, req, taskid, date, hours,
                         description=None):
        if isinstance(date, basestring):
            d = date.split('-')
            date = datetime.date(int(d[0]), int(d[1]), int(d[2]))

        if isinstance(hours, basestring):
            hours = float(hours)

        self.timemanager.add_interval(req.authname, date, hours, taskid,
                                      description or u'')

        usertotal = self.timemanager.get_total_time(taskid, req.authname)
        total = self.timemanager.get_total_time(taskid, req.authname)

        return {'totalhours': total,
                'usertotalhours': usertotal,
                'estimatedhours': self._get_estimated(taskid)}

    def json_info(self, req, taskid):
        usertotal = self.timemanager.get_total_time(taskid, req.authname)
        total = self.timemanager.get_total_time(taskid)
        return {'usertotalhours': usertotal,
                'totalhours': total,
                'estimatedhours': self._get_estimated(taskid)}

    def json_get_bookings(self, req, startdate, enddate=None):
        startdate = build_date(startdate)
        if enddate is None:
            enddate = datetime.datetime(startdate.year, startdate.month,
                                        startdate.day,
                                        23, 59)
        else:
            enddate = build_date(enddate)

        intervals = self.timemanager.get_intervals(userid=req.authname,
                                                   startdate=startdate,
                                                   enddate=enddate)
        bookings = [{'ticketid': x.taskid,
                     'intervalid': x.intervalid,
                     'hours': x.hours,
                     'date': date_to_json(x.date),
                     'summary': x.summary,
                     'userid': x.userid,
                     'can_edit': x.userid == req.authname,
                     'url': req.base_url+'/ticket/'+x.taskid}
                    for x in sorted(intervals, interval_cmp)]

        return {'bookings': bookings}

    def json_get_ticket_bookings(self, req, ticketid):
        intervals = self.timemanager.get_intervals(taskid=ticketid)
        bookings = [{'ticketid': x.taskid,
                     'intervalid': x.intervalid,
                     'hours': x.hours,
                     'date': date_to_json(x.date),
                     'summary': x.summary,
                     'userid': x.userid,
                     'can_edit': x.userid == req.authname,
                     'url': req.base_url+'/ticket/'+x.taskid}
                    for x in sorted(intervals, interval_cmp)]

        return {'bookings': bookings}

    def _get_estimated(self, taskid):
        estimated = 0

        cursor = self.env.get_db_cnx().cursor()
        cursor.execute('SELECT * FROM ticket_custom '
                       'where ticket=%s and name=%s',
                       (taskid, 'estimatedhours'))
        val = cursor.fetchone()
        if val:
            estimated = float(val[2] or 0)
        return estimated

    def json_report_week(self, req, somedate=None):
        today = datetime.datetime.today()
        today = datetime.datetime(today.year, today.month, today.day)

        somedate = build_date(somedate or today)

        day = somedate or today
        while calendar.weekday(day.year, day.month, day.day) != 6:
            day -= ONE_DAY

        date_format = '%a, %b %d, 20%y'
        days = []
        singletotal = self.timemanager.get_total_time(userid=req.authname,
                                                      startdate=day,
                                                      enddate=day)
        days.append({
            'label': day.strftime(date_format),
            'singletotal': singletotal,
            'date': date_to_json(day),
            'today': sameday(day, today),
            })
        day += ONE_DAY
        while calendar.weekday(day.year, day.month, day.day) < 6:
            singletotal = self.timemanager.get_total_time(userid=req.authname,
                                                          startdate=day,
                                                          enddate=day)
            days.append({
                'label': day.strftime(date_format),
                'singletotal': singletotal,
                'date': date_to_json(day),
                'today': sameday(day, today),
                })

            day += ONE_DAY

        return {'days': days}

    def _get_ticket(self, ticketid):
        sql = "SELECT id,  summary " \
              "FROM ticket WHERE id='%s'" % ticketid
        dbmgr = dbapi.DatabaseManager(self.env)
        conn = dbmgr.get_connection()
        cursor = conn.cursor()
        res = cursor.execute(sql)

        entry = iter(res).next()

        data = {'ticketid': ticketid,
                'summary': entry[1]}

        cursor.close()
        return data

    def json_report_range(self, req, startdate, enddate):
        startdate = build_date(startdate)
        enddate = build_date(enddate)

        intervals = self.timemanager.get_intervals(None, startdate,
                                                   enddate)
        total_group = {'hours': 0.0,
                       'estimated': 0.0,
                       'tickets': {}}
        groups = {}
        cursor = self.env.get_db_cnx().cursor()
        for interval in intervals:
            ticket = total_group['tickets'].get(interval.taskid, None)

            estimated = 0.0
            if ticket is None:
                cursor.execute('SELECT * FROM ticket_custom '
                               'where ticket=%s and name=%s',
                               (interval.taskid, 'estimatedhours'))
                val = cursor.fetchone()
                if val:
                    estimated = float(val[2] or 0)

                ticket = total_group['tickets'][interval.taskid] = {
                    'hours': 0,
                    'taskid': interval.taskid,
                    'estimated': estimated,
                    }
                total_group['estimated'] += estimated

            # While researching ticket #79 it was discovered that some
            # corrupt interval data existed where interval.hours
            # could be None.  This should be cleaned up.

            ticket['hours'] += interval.hours or 0.0
            total_group['hours'] += interval.hours or 0.0

            group = groups.get(interval.userid, None)
            if group is None:
                group = groups[interval.userid] = {
                    'tickets': {},
                    'hours': 0.0,
                    'estimated': 0.0,
                    }

            group['hours'] += interval.hours or 0.0

            ticket = group['tickets'].get(interval.taskid, None)
            if ticket is None:
                ticket = group['tickets'][interval.taskid] = {
                    'hours': 0.0,
                    'taskid': interval.taskid,
                    'estimated': estimated,
                    }
                group['estimated'] += ticket['estimated']
            ticket['hours'] += interval.hours or 0.0
            ticket['summary'] = self._get_ticket(interval.taskid)['summary']

        items = []

        all = sorted(groups.items(), lambda x, y: cmp(x[0], y[0]))
        all.append((u'Grand Total', total_group))

        for user, group in all:
            tickets = group['tickets']
            res = {'label': user,
                   'tickets': sorted(tickets.values(), ticket_cmp),
                   'hours': group['hours'],
                   'estimated': group['estimated']}
            items.append(res)

        return {'ticket_groups': items,
                'totalhours': total_group['hours']}


def ticket_cmp(x, y):
    return cmp(int(x['taskid']), int(y['taskid']))


class TimeTrackingReporter(traccore.Component):
    """Time tracking reporting functionality."""

    traccore.implements(api.IRequestHandler,
                        chrome.INavigationContributor)

    def get_active_navigation_item(self, req):
        return 'timetracking_report'

    def get_navigation_items(self, req):
        yield ('mainnav', 'timetracking_report',
               builder.a('Time Tracking', href=req.href.timetracking_report()))

    def match_request(self, req):
        return req.path_info.startswith('/timetracking_report')

    def process_request(self, req):
        setup_cluetimer_resources(req)
        utils.add_script(req, 'timetracking/enable-reporting.js')
        return 'time-report.html', {}, None
