from trac.web import chrome


def add_link(req, rel, href, title=None, mimetype=None, classname=None):
    """Add a link to the chrome info that will be inserted as <link> element in
    the <head> of the generated HTML
    """
    linkid = '%s:%s' % (rel, href)
    linkset = req.chrome.setdefault('linkset', set())
    if linkid in linkset:
        return # Already added that link

    link = {'href': href, 'title': title, 'type': mimetype, 'class': classname}
    links = req.chrome.setdefault('links', {})
    links.setdefault(rel, []).append(link)
    linkset.add(linkid)


def add_stylesheet(req, filename, mimetype='text/css'):
    if filename.startswith('common/') and 'htdocs_location' in req.chrome:
        href = chrome.Href(req.chrome['htdocs_location'])
        filename = filename[7:]
    else:
        href = req.href
        if not filename.startswith('/'):
            href = href.chrome
    if filename.startswith('http:') or filename.startswith('https:'):
        full = filename
    else:
        full = href(filename)
    add_link(req, 'stylesheet', full, mimetype=mimetype)


def add_script(req, filename, mimetype='text/javascript'):
    scriptset = req.chrome.setdefault('scriptset', set())
    if filename in scriptset:
        return False # Already added that script

    if filename.startswith('http:') or filename.startswith('https:'):
        script = {'href': filename, 'type': mimetype}
        req.chrome.setdefault('scripts', []).append(script)
        scriptset.add(filename)
        return

    if filename.startswith('common/') and 'htdocs_location' in req.chrome:
        href = chrome.Href(req.chrome['htdocs_location'])
        path = filename[7:]
    else:
        href = req.href
        if not filename.startswith('/'):
            href = href.chrome
        path = filename
    script = {'href': href(path), 'type': mimetype}

    req.chrome.setdefault('scripts', []).append(script)
    scriptset.add(filename)
