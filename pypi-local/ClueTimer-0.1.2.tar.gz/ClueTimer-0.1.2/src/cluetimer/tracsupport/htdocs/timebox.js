// timetracking hookup

dojo.require('dojo.parser');
dojo.require('dojo.string');
dojo.require('dijit.Dialog');
dojo.require('dijit.TitlePane');
dojo.require('dijit.form.DateTextBox');
dojo.require('dijit.InlineEditBox');
dojo.require('dijit.form.Textarea');
dojo.require('dijit.form.NumberSpinner');

cluetimer.trac.timebox = {

    init: function() {
        if (cluetimer.ticket_url != null) {
            var pieces = cluetimer.ticket_url.split('/');
            cluetimer.trac.timebox.ticketid = pieces[pieces.length-1];
        }
    },

    display_timebox: function() {
        var nodes = dojo.query('li.first a', dojo.byId('metanav'));
        if (nodes.length > 0) {
            if (nodes[0].href.indexOf('/login') > -1)
                return;
        }

        var boxcontainer = dojo.byId('cluetimer-box-container');
        if (boxcontainer == null) {
            boxcontainer = dojo.doc.createElement('div');
            dojo.attr(boxcontainer, 'id', 'cluetimer-box-container');
            dojo.place(boxcontainer, dojo.body(), 'first');
        }

        var timebox = dojo.byId('cluetimer-timebox');

        if (timebox == null) {
            timebox = dojo.doc.createElement('div');
            dojo.attr(timebox, 'id', 'cluetimer-timebox');

            var wrapper = dojo.doc.createElement('div');
            dojo.attr(wrapper, 'id', 'cluetimer-timebox-wrapper');
            boxcontainer.appendChild(wrapper);
            
            var pane = new dijit.TitlePane({title: 'Book Hours'});
            pane.setContent(timebox);

            var form = dojo.doc.createElement('form');
            timebox.appendChild(form);

            form.appendChild(cluetimer.trac.reporter.create_date_field('cluetimer-date', 'Date:'));
            dijit.byId('cluetimer-date').setValue(new Date());

            var field = dojo.doc.createElement('div');
            dojo.addClass(field, 'field');
            form.appendChild(field);
            var label = dojo.doc.createElement('label');
            label.innerHTML = 'Hours:';
            field.appendChild(label);
            var widget = new dijit.form.NumberSpinner({id: 'cluetimer-hours'});
            widget.setValue(1);
            field.appendChild(widget.domNode);

            field = dojo.doc.createElement('div');
            dojo.addClass(field, 'field');
            form.appendChild(field);
            label = dojo.doc.createElement('label');
            label.innerHTML = 'Summary:';
            field.appendChild(label);
            widget = new dijit.form.Textarea({id: 'cluetimer-summary'});
            field.appendChild(widget.domNode);

            widget = new dijit.form.Button({id: 'cluetimer-add-hours', label: 'Add Hours', onClick: cluetimer.trac.timebox.submit_add_hours});
            form.appendChild(widget.domNode);


            var dl = dojo.doc.createElement('dl');
            form.appendChild(dl);
            var dt = dojo.doc.createElement('dt');
            dt.innerHTML = 'Mine:';
            dl.appendChild(dt);
            var dd = dojo.doc.createElement('dd');
            dojo.attr(dd, 'id', 'cluetimer-mytotalhours');
            dd.innerHTML = '&nbsp;';
            dl.appendChild(dd);

            dt = dojo.doc.createElement('dt');
            dt.innerHTML = 'Total:';
            dl.appendChild(dt);
            dd = dojo.doc.createElement('dd');
            dojo.attr(dd, 'id', 'cluetimer-totalhours');
            dd.innerHTML = '&nbsp;';
            dl.appendChild(dd);

            dt = dojo.doc.createElement('dt');
            dt.innerHTML = 'Est:';
            dl.appendChild(dt);
            dd = dojo.doc.createElement('dd');
            dojo.attr(dd, 'id', 'cluetimer-estimatedhours');
            dd.innerHTML = '&nbsp;';
            dl.appendChild(dd);

            var list = dojo.doc.createElement('ul');
            form.appendChild(list);
            var li = dojo.doc.createElement('li');
            list.appendChild(li);
            var link = dojo.doc.createElement('a');
            li.appendChild(link);
            dojo.attr(link, 'id', 'cluetimer-timebox-refresh-link');
            dojo.attr(link, 'href', '#');
            link.innerHTML = 'Refresh';
            dojo.connect(link, 'onclick', null, function() {
                cluetimer.trac.timebox.update_info();
                cluetimer.trac.timebox.refresh_bookingbox();
            });

            var div = dojo.doc.createElement('div');
            dojo.attr(div, 'id', 'cluetimer-timebox-loader');
            form.appendChild(div);            


            wrapper.appendChild(pane.domNode);
        }

        var bookingbox = dojo.byId('cluetimer-bookingbox');

        if (bookingbox == null) {
            bookingbox = dojo.doc.createElement('div');
            dojo.attr(bookingbox, 'id', 'cluetimer-bookingbox');

            var wrapper = dojo.doc.createElement('div');
            dojo.attr(wrapper, 'id', 'cluetimer-bookingbox-wrapper');
            boxcontainer.appendChild(wrapper);

            var pane = new dijit.TitlePane({title: 'Bookings', open: false, id: 'cluetimer-bookingbox-pane'});
            pane.setContent(bookingbox);

            dojo.connect(pane, 'toggle', null, function() {
                dojo.toggleClass(dojo.byId('cluetimer-box-container'), 'expanded');
                if (cluetimer.trac.timebox.bookingbox_needs_refresh) {
                    cluetimer.trac.timebox.bookingbox_needs_refresh = false;
                    cluetimer.trac.timebox.refresh_bookingbox();
                }
            });

            var form = dojo.doc.createElement('form');
            bookingbox.appendChild(form);

            wrapper.appendChild(pane.domNode);
        }

        cluetimer.trac.timebox.update_info();
    },

    bookingbox_needs_refresh: true,

    refresh_bookingbox: function() {
        var pane = dijit.byId('cluetimer-bookingbox-pane');
        if (pane != null && pane.open) {
            var bookingbox = dojo.byId('cluetimer-bookingbox');
            cluetimer.trac.timebox.populate_bookings(bookingbox, function() {
                return cluetimer.time_tracker.get_ticket_bookings(cluetimer.trac.timebox.ticketid);
            }, false, true);
        } else {
            cluetimer.trac.timebox.bookingbox_needs_refresh = true;
        }
    },

    update_date: function(el, datearg) {
        var somedate = datearg;
        if (somedate == null)
            somedate = new Date();
        var month = '' + (somedate.getMonth()+1);
        var day = '' + somedate.getDate();
        var year = '' + (somedate.getFullYear());
        var date = month+"/"+day+"/"+year;

        el.value = date;
    },

    update_info: function() {
        var loader = dojo.byId('cluetimer-timebox-loader');
        loader.innerHTML = '<span class="cluetimer-loading">Loading...</span>';
        var deferred = cluetimer.time_tracker.info(cluetimer.trac.timebox.ticketid);
        deferred.addCallback(function(result) {
            dojo.byId('cluetimer-totalhours').innerHTML = result.totalhours;
            dojo.byId('cluetimer-mytotalhours').innerHTML = result.usertotalhours;
            dojo.byId('cluetimer-estimatedhours').innerHTML = result.estimatedhours;
            loader.innerHTML = '';
        });
        deferred.addErrback(function(result) {
            dojo.byId('cluetimer-error').innerHTML = result;
        });
    },

    submit_add_hours: function() {
        var hours_el = dojo.byId('cluetimer-hours');
        var hours = hours_el.value;
        if (dojo.string.trim(hours).length == 0) {
            alert('Please specify some hours');
            return false;
        }

        var datewidget = dijit.byId('cluetimer-date');
        var date = datewidget.value;
        if (date == null) {
            alert('Please specify a time');
            return false;
        }

        var summary_el = dijit.byId('cluetimer-summary');
        var summary = summary_el.value;

        cluetimer.trac.timebox.set_timebox_enabled(false);
        dijit.byId('cluetimer-add-hours').setLabel('Adding...');

        deferred = cluetimer.time_tracker.postbooking(cluetimer.trac.timebox.ticketid,
                                                      cluetimer.trac.reporter.isodate(date), hours,
                                                      summary);
        deferred.addCallback(function(result) {
            dijit.byId('cluetimer-add-hours').setLabel('Add Hours');
            cluetimer.trac.timebox.set_timebox_enabled(true);
            dojo.byId('cluetimer-totalhours').innerHTML = result.totalhours;
            dojo.byId('cluetimer-estimatedhours').innerHTML = result.estimatedhours;
            dojo.byId('cluetimer-mytotalhours').innerHTML = result.usertotalhours;
            cluetimer.trac.timebox.refresh_bookingbox();
        });
        deferred.addErrback(function(result) {
            dijit.byId('cluetimer-add-hours').setLabel('Add Hours');
            dojo.byId('cluetimer-error').innerHTML = result;
            track_cluetimer.set_timebox_enabled(true);
        });
    },

    set_timebox_enabled: function(v) {
        var inputs_disabled = true;
        if (v) {
            inputs_disabled = false;
            dojo.removeClass(dojo.byId('cluetimer-timebox'), 'disabled')
        } else {
            dojo.addClass(dojo.byId('cluetimer-timebox'), 'disabled')
        }

        dijit.byId('cluetimer-add-hours').setDisabled(inputs_disabled);
        dijit.byId('cluetimer-date').setDisabled(inputs_disabled);
        dijit.byId('cluetimer-hours').setDisabled(inputs_disabled);
        dijit.byId('cluetimer-summary').setDisabled(inputs_disabled);
    },

    populate_bookings: function(parent, booking_func, showticketid, showuser) {
        if (showticketid == null)
            showticketid = true;
        if (showuser == null)
            showuser = false;

        var table = null;
        var nodes = dojo.query('table.cluetimer-bookings', parent);
        var tbody = null;

        if (nodes.length > 0) {
            table = nodes[0];
            tbody = dojo.query('tbody', table)[0];
        } else {
            table = dojo.doc.createElement('table');
            parent.appendChild(table);
            dojo.attr(table, 'id', 'cluetimer-daily-bookings');
            dojo.addClass(table, 'cluetimer-bookings');
            dojo.addClass(table, 'listing');

            var thead = dojo.doc.createElement('thead');
            table.appendChild(thead);

            var th = null;
            
            if (showticketid) {
                th = dojo.doc.createElement('th');
                th.innerHTML = 'Ticket';
                dojo.place(th, thead, 'last');
            }

            th = dojo.doc.createElement('th');
            th.innerHTML = 'Date';
            dojo.place(th, thead, 'last');

            if (showuser) {
                th = dojo.doc.createElement('th');
                th.innerHTML = 'Owner';
                dojo.place(th, thead, 'last');
            }

            th = dojo.doc.createElement('th');
            th.innerHTML = 'Hrs';
            dojo.place(th, thead, 'last');

            th = dojo.doc.createElement('th');
            dojo.addClass(th, 'summary');
            th.innerHTML = 'Summary';
            dojo.place(th, thead, 'last');

            tbody = dojo.doc.createElement('tbody');
            table.appendChild(tbody);
        }

        cluetimer.trac.reporter.clear_children(tbody);

        var tr = dojo.doc.createElement('tr');
        dojo.place(tr, tbody, 'last');

        var td = dojo.doc.createElement('td');
        dojo.attr(td, 'colspan', '3');
        dojo.place(td, tr, 'last');
        td.innerHTML = '<span class="cluetimer-loading">Loading...</span>';

        var deferred = booking_func();
        deferred.addCallback(function(result) {
            cluetimer.trac.reporter.clear_children(tbody);
            dojo.forEach(result.bookings, function(item, index, array) {
                var tr = dojo.doc.createElement('tr');
                dojo.place(tr, tbody, 'last');
                if (index % 2 == 0)
                    dojo.addClass(tr, 'even')
                else
                    dojo.addClass(tr, 'odd')

                if (!item.can_edit)
                    dojo.addClass(tr, 'not-editable');

                var td = null;

                if (showticketid) {
                    td = dojo.doc.createElement('td');
                    dojo.place(td, tr, 'last');
                    td.innerHTML = '<a href="'+item.url+'">#'+item.ticketid+'</a>';
                }

                td = dojo.doc.createElement('td');
                dojo.place(td, tr, 'last');
                td.innerHTML = item.date;

                if (showuser) {
                    td = dojo.doc.createElement('td');
                    dojo.place(td, tr, 'last');
                    td.innerHTML = item.userid;
                }

                td = dojo.doc.createElement('td');
                dojo.place(td, tr, 'last');
                var d = dojo.doc.createElement('div');
                td.appendChild(d);

                var savefunc = null;
                if (item.can_edit) {
                    savefunc = function() {
                        cluetimer.trac.reporter._save_inline(this, arguments[0]);
'cluetimer-timebox-refresh-link'
                        var refreshlink = dojo.byId('cluetimer-timebox-refresh-link');
                        if (refreshlink != null)
                            cluetimer.trac.timebox.update_info();
                        
                    };
                    var hourbox = new dijit.InlineEditBox({title: 'Hours', onChange: savefunc, editor: 'dijit.form.NumberSpinner'}, d);
                    hourbox.intervalid = item.intervalid;
                    hourbox.setValue(''+item.hours);
                } else {
                    d.innerHTML = item.hours;
                    dojo.addClass(tr, 'cluetimer-not-editable');
                }
                
                td = dojo.doc.createElement('td');
                dojo.place(td, tr, 'last');
                d = dojo.doc.createElement('div');
                td.appendChild(d);

                if (item.can_edit) {
                    var summarybox = new dijit.InlineEditBox({title: 'Summary', editor: 'dijit.form.Textarea', autoSave: false, onChange: savefunc}, d);
                    summarybox.intervalid = item.intervalid;
                    summarybox.setValue(''+item.summary);
                } else {
                    var v = item.summary;
                    if (dojo.trim(v).length == 0)
                        v = '&nbsp;';
                    d.innerHTML = v;
                }
            });

            if (result.bookings.length == 0) {
                var tr = dojo.doc.createElement('tr');
                dojo.place(tr, tbody, 'last');
                
                var td = dojo.doc.createElement('td');
                dojo.attr(td, 'colspan', '3');
                dojo.place(td, tr, 'last');
                td.innerHTML = 'no bookings';
            }
        });
    }

};

dojo.addOnLoad(cluetimer.trac.timebox.init);
