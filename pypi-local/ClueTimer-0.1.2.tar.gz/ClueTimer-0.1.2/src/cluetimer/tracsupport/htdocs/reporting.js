dojo.require("dijit.form.Button");
dojo.require("dijit.form.DateTextBox");

cluetimer.trac.reporter = {

    nav_header: '\
      <div class="cluetimer-week-nav">\
        <div id="cluetimer-week-date">&nbsp;</div>\
        <div class="prev"><a id="cluetimer-week-prev" href="#">&lt;&lt; Previous Week</a></div>\
        <div class="next"><a id="cluetimer-week-next" href="#">Next Week &gt;&gt;</a></div>\
      </div>\
    ',

    init: function() {
    },

    create_date_field: function(name, title) {
        var field = dojo.doc.createElement('div');
        dojo.addClass(field, 'field');
        var label = dojo.doc.createElement('label');
        field.appendChild(label);            
        label.innerHTML = title;
        var widget = new dijit.form.DateTextBox({id: name});
        field.appendChild(widget.domNode);

        widget.name = name;

        return field;
    },

    activate_reporter: function() {
        var reporter = cluetimer.trac.reporter;
        reporter.display_week();

        var fullreport = dojo.byId('cluetimer-report-fullreport');
        if (fullreport == null) {
            fullreport = dojo.doc.createElement('form');
            dojo.attr(fullreport, 'id', 'cluetimer-report-fullreport');
            dojo.place(fullreport, dojo.byId('cluetimer-reporter'), 'last');

            var fieldset = dojo.doc.createElement('fieldset');
            fieldset.innerHTML = '<legend>Date Range Report</legend>';
            fullreport.appendChild(fieldset);


            fieldset.appendChild(reporter.create_date_field('cluetimer-startdate', 'Start Date:'));
            fieldset.appendChild(reporter.create_date_field('cluetimer-enddate', 'End Date:'));
            
            var action = new dijit.form.Button({label: 'report',
                                                onClick: reporter.report});
            fieldset.appendChild(action.domNode);
       }

    },

    report: function() {
        var startdate = dojo.byId('cluetimer-startdate').value;
        if (dojo.string.trim(startdate).length == 0)
            return
        startdate = cluetimer.trac.reporter.isodate(startdate);
        var enddate = dojo.byId('cluetimer-enddate').value;
        if (dojo.string.trim(enddate).length == 0)
            return
        enddate = cluetimer.trac.reporter.isodate(enddate);

        var table = dojo.byId('cluetimer-report-table');
        var created = false;
        if (table == null) {
            table = dojo.doc.createElement('table');
            table.id = 'cluetimer-report-table';
            dojo.addClass(table, 'listing');
            
            var thead = dojo.doc.createElement('thead');
            thead.innerHTML = '<th class="ticket">Ticket</th>';
            thead.innerHTML += '<th class="summary">Summary</th>';
            thead.innerHTML += '<th class="hours">Booked Hours</th>';
            thead.innerHTML += '<th class="estimated">Estimated Hours</th>';
            table.appendChild(thead);

            var tbody = dojo.doc.createElement('tbody');
            dojo.attr(tbody, 'id', 'cluetimer-report-body');
            table.appendChild(tbody);
            created = true;

            var fieldset = dojo.query('fieldset', dojo.byId('cluetimer-report-fullreport'))[0];
            dojo.place(table, fieldset, 'last');
        }

        var tbody = dojo.byId('cluetimer-report-body');
        cluetimer.trac.reporter.clear_children(tbody);
        var tr = dojo.doc.createElement('tr');
        dojo.place(tr, tbody, 'last');

        var td = dojo.doc.createElement('td');
        dojo.attr(td, 'colspan', '3');
        dojo.place(td, tr, 'last');
        td.innerHTML = '<span class="cluetimer-loading">Loading...</span>';

        var deferred = cluetimer.time_tracker.report_range(startdate, enddate);
        deferred.addErrback(function(result) {
            dojo.byId('cluetimer-error').innerHTML = result;
        });
        deferred.addCallback(function(result) {
            cluetimer.trac.reporter.clear_children(tbody);
            for (var x = 0; x < result.ticket_groups.length; x++) {
                var ticket_group = result.ticket_groups[x];

                var tr = dojo.doc.createElement('tr');
                dojo.addClass(tr, 'cluetimer-ticket-group')
                var th = dojo.doc.createElement('th');
                th.innerHTML = ticket_group.label;
                dojo.place(th, tr, 'last');

                th = dojo.doc.createElement('th');
                th.innerHTML = '';
                dojo.place(th, tr, 'last');

                th = dojo.doc.createElement('th');
                th.innerHTML = ticket_group.hours;
                dojo.place(th, tr, 'last');

                th = dojo.doc.createElement('th');
                th.innerHTML = ticket_group.estimated;
                dojo.place(th, tr, 'last');

                dojo.place(tr, tbody, 'last');

                for (var y = 0; y < ticket_group.tickets.length; y++) {
                    var ticket = ticket_group.tickets[y];
                    tr = dojo.doc.createElement('tr');

                    var td = dojo.doc.createElement('td');
                    td.innerHTML = '<a href="ticket/'+ticket.taskid+'">#'+ticket.taskid+'</a>';
                    dojo.place(td, tr, 'last');

                    td = dojo.doc.createElement('td');
                    if (ticket.summary) {
                        td.innerHTML = '<a href="ticket/'+ticket.taskid+'">'+ticket.summary+'</a>';
                    }
                    dojo.place(td, tr, 'last');

                    td = dojo.doc.createElement('td');
                    td.innerHTML = ticket.hours;
                    dojo.place(td, tr, 'last');

                    td = dojo.doc.createElement('td');
                    td.innerHTML = ticket.estimated;
                    dojo.place(td, tr, 'last');

                    dojo.place(tr, tbody, 'last');
                }
            }
        });
    },

    clear_children: function(node) {
        while (node.childNodes.length > 0) {
            node.removeChild(node.childNodes[0]);
        }
    },

    prev_week: function() {
        var lastdate = cluetimer.trac.reporter.lastdate;
        if (lastdate == null)
            lastdate = new Date();
        var somedate = new Date(lastdate.getFullYear(), lastdate.getMonth(), lastdate.getDate() - 7);
        cluetimer.trac.reporter.display_week(somedate);
    },

    next_week: function() {
        var lastdate = cluetimer.trac.reporter.lastdate;
        if (lastdate == null)
            lastdate = new Date();
        var somedate = new Date(lastdate.getFullYear(), lastdate.getMonth(), lastdate.getDate() + 7);
        cluetimer.trac.reporter.display_week(somedate);
    },

    lastdate: null,

    str_to_date: function(str) {
        var year = null;
        var month = null;
        var day = null;

        if (str.indexOf('-') > -1) {
            var pieces = str.split('-');
            year = parseInt(pieces[0]);

            month = pieces[1];
            if (month.charAt(0) == '0')
                month = month.substring(1);
            month = parseInt(month) - 1;

            day = pieces[2];
            if (day.charAt(0) == '0')
                day = day.substring(1);
            day = parseInt(day);
        } else if (str.indexOf('/') > -1) {
            var pieces = str.split('/');

            month = pieces[0];
            if (month.indexOf('0') == 0)
                month = month[1];
            month = parseInt(month) - 1;

            day = pieces[1];
            if (day.indexOf('0') == 0)
                day = day[1];
            day = parseInt(day);

            year = parseInt(pieces[2]);
        }

        var r = new Date(year, month, day) 
        return r;
    },

    isodate: function(somedate) {
        var s = somedate;
        if (!(somedate instanceof Date))
            s = cluetimer.trac.reporter.str_to_date(somedate);

        s = s.getFullYear() + '-' + (s.getMonth()+1) + '-' + s.getDate();

        return s;
    },

    pretty_date: function(somedate) {
        var pieces = somedate.toString().split(' ')
        return pieces[0] + ', ' + pieces[1] + ' ' + pieces[2] + ', ' + pieces[3];
    },

    display_bookings: function(somedate) {
        var reporter = cluetimer.trac.reporter;

        if (somedate == null)
            somedate = cluetimer.trac.reporter.last_bookings_date;
        if (somedate == null)
            somedate = cluetimer.trac.reporter.isodate(new Date());

        var fieldset = dojo.byId('cluetimer-daily-bookings-fieldset');
        var table = null;
        var tbody = null;

        if (fieldset == null) {
            fieldset = dojo.doc.createElement('fieldset');
            dojo.attr(fieldset, 'id', 'cluetimer-daily-bookings-fieldset');
            var el = dojo.byId('cluetimer-my-bookings').parentNode;
            dojo.place(fieldset, el, 'after');

            var legend = dojo.doc.createElement('legend');
            dojo.attr(legend, 'id', 'cluetimer-daily-bookings-legend');
            dojo.place(legend, fieldset, 'last');

            var bookings_container = dojo.doc.createElement('div');
            dojo.attr(bookings_container, 'id', 'cluetimer-daily-bookings-container');
            dojo.place(bookings_container, fieldset, 'last');
        }

        var legend = dojo.byId('cluetimer-daily-bookings-legend');
        legend.innerHTML = 'Bookings for ' + somedate;

        var bookings_container = dojo.byId('cluetimer-daily-bookings-container');

        var bookings_func = function() {
            return cluetimer.time_tracker.get_bookings(somedate);
        };

        cluetimer.trac.reporter.last_bookings_date = somedate;
        cluetimer.trac.timebox.populate_bookings(bookings_container, bookings_func);
    },

    _save_inline: function(widget, value) {
        if (widget.title == 'Hours') {
            value = parseFloat(value);
            var savehours = function() {
                if (value <= 0) {
                    cluetimer.time_tracker.delete_booking(widget.intervalid);
                    // only happens if bookingbox is present
                    cluetimer.trac.timebox.refresh_bookingbox();
                    var reportfieldset = dojo.byId('cluetimer-daily-bookings-fieldset');
                    if (reportfieldset != null) {
                        cluetimer.trac.reporter.display_bookings();
                    }
                } else
                    cluetimer.time_tracker.updatebooking_hours(widget.intervalid, value);
            };
            if (value <= 0) {
                var title = 'Are you sure?';
                var message = 'Are you sure you want to delete this booking?';
                cluetimer.trac.reporter.confirm(title, message, savehours, null, 'yes', 'no');
            } else {
                savehours();
            }

        } else if (widget.title == 'Summary') {
            cluetimer.time_tracker.updatebooking_summary(widget.intervalid,
                                                         value);
        }
    },

    confirm: function(title, message, okcallback, cancelcallback, oktext, canceltext) {
        if (oktext == null)
            oktext = 'ok';
        if (canceltext == null)
            canceltext = 'cancel';

        var dialog = new dijit.Dialog({title: title});
        var content = dojo.doc.createElement('div');
        
        var p = dojo.doc.createElement('p');
        p.innerHTML = message;
        content.appendChild(p);

        var ok = new dijit.form.Button({label: oktext, onClick: function() {
            if (okcallback != null)
                okcallback();
            dialog.hide();
            dialog.destroy();
        }});
        content.appendChild(ok.domNode);
        var cancel = new dijit.form.Button({label: canceltext,
                                            onClick: function() {
            if (cancelcallback != null)
                cancelcallback();
            dialog.hide();
            dialog.destroy();
        }});
        content.appendChild(cancel.domNode);

        dialog.setContent(content);
        dialog.show();
    },

    display_week: function(somedate) {
        var deferred = null;
        if (somedate != null) {
            var isodate = somedate.getFullYear() + '-' + (somedate.getMonth()+1) + '-' + somedate.getDate();
            deferred = cluetimer.time_tracker.report_week(isodate);
        } else
            deferred = cluetimer.time_tracker.report_week();

        var table_parent = dojo.byId('cluetimer-my-bookings');
        dojo.addClass(table_parent, 'disabled');
        table_parent.innerHTML = '<span class="cluetimer-loading">Loading...</span>';

        deferred.addCallback(function(result) {
            var reporter = cluetimer.trac.reporter;
            reporter.lastdate = reporter.str_to_date(result.days[0].date);

            table_parent.innerHTML = '';
            var table = dojo.byId('cluetimer-week');
            var created = false;
            if (table == null) {
                table = dojo.doc.createElement('table');
                dojo.attr(table, 'id', 'cluetimer-week');
                dojo.addClass(table, 'listing');
                created = true;
            }

            var thead = dojo.doc.createElement('thead');
            dojo.place(thead, table, 'last');

            var tr = dojo.doc.createElement('tr');
            dojo.place(tr, thead, 'last');

            dojo.forEach(result.days, function(item, index, array) {
                var th = dojo.doc.createElement('th');
                dojo.place(th, tr, 'last');

                var day = item;
                if (day.today)
                    dojo.addClass(th, 'today');
                th.innerHTML = day.label;
            });

            var tbody = dojo.doc.createElement('tbody');
            dojo.place(tbody, table, 'last');

            tr = dojo.doc.createElement('tr');
            dojo.place(tr, tbody, 'last');

            dojo.forEach(result.days, function(item, index, array) {
                var td = dojo.doc.createElement('td');
                dojo.place(td, tr, 'last');

                var day = item;
                if (day.today)
                    dojo.addClass(td, 'today');

                td.innerHTML = day.singletotal + '&nbsp;';
                var anchor = dojo.doc.createElement('a');
                dojo.place(anchor, td, 'last');
                dojo.attr(anchor, 'href', '#');
                anchor.innerHTML = '(details/update)';

                dojo.connect(anchor, 'onclick', null, function() {
                    reporter.display_bookings(day.date);
                });
            });

            if (created) {
                dojo.byId('cluetimer-my-bookings').innerHTML = '';
                dojo.place(table, dojo.byId('cluetimer-my-bookings'), 'first');
    
                var nav_el = dojo.doc.createElement('div');
                nav_el.innerHTML = cluetimer.trac.reporter.nav_header; 
                dojo.place(nav_el, dojo.byId('cluetimer-my-bookings'), 'first');

                dojo.connect(dojo.byId('cluetimer-week-prev'),
                             'onclick', null, cluetimer.trac.reporter.prev_week);
                dojo.connect(dojo.byId('cluetimer-week-next'),
                             'onclick', null, cluetimer.trac.reporter.next_week);
            }

            var start = cluetimer.trac.reporter.str_to_date(result.days[0].date);
            dijit.byId('cluetimer-startdate').setValue(start);
            var end = cluetimer.trac.reporter.str_to_date(result.days[result.days.length-1].date);
            dijit.byId('cluetimer-enddate').setValue(end);

            dojo.byId('cluetimer-week-date').innerHTML = 'Week of: ' + cluetimer.trac.reporter.pretty_date(cluetimer.trac.reporter.lastdate);
            dojo.removeClass(dojo.byId('cluetimer-my-bookings'), 'disabled');
        });

        deferred.addErrback(function(result) {
            dojo.byId('cluetimer-error').innerHTML = result;
        });
    }
}

dojo.addOnLoad(cluetimer.trac.reporter.init);
