var djConfig = {
    usePlainJson: true
};
