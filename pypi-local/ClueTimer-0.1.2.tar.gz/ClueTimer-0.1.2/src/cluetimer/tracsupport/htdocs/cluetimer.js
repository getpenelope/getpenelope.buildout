dojo.require('dojox.rpc.Service');
dojo.require('dojox.rpc.JsonRPC');

var cluetimer = {
    init: function() {
        var url = window.location.href;
        if (url.indexOf('#') > -1)
            url = url.split('#')[0];
        cluetimer.ticket_url = url;
        cluetimer.service_url = url+'/json_timetracking';
        if (cluetimer.time_tracker == null)
            cluetimer.setup_services();
    },

    setup_services: function() {
        // needs to be lazily setup
        cluetimer.time_tracker = new dojox.rpc.Service({
            envelope: 'JSON-RPC-1.0',
            transport: 'POST',
            target: cluetimer.service_url,
            contentType: 'application/json',
            services: {
                info: {
                    returns: {'type': 'string'},
                    parameters: []
                },
                postbooking: {
                    returns: {'type': 'string'},
                    parameters: [{'type': 'string',
                                  'type': 'string',
                                  'type': 'int',
                                  'type': 'string'}]
                },
                report_week: {
                    parameters: [{'type': 'string'}]
                },
                report_range: {
                    parameters: [{'type': 'string',
                                  'type': 'string'}]
                },
                get_bookings: {
                    parameters: [{'type': 'string',
                                  'type': 'string'}]
                },
                get_ticket_bookings: {
                    parameters: [{'type': 'string'}]
                },
                updatebooking_hours: {
                    parameters: [{'type': 'string',
                                  'type': 'string'}]
                },
                updatebooking_summary: {
                    parameters: [{'type': 'string',
                                  'type': 'string'}]
                },
                delete_booking: {
                    parameters: [{'type': 'string'}]
                }
            }
        });
    }
};

dojo.addOnLoad(cluetimer.init);
