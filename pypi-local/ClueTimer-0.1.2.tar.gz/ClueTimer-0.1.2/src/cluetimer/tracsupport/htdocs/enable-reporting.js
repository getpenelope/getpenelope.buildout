dojo.addOnLoad(cluetimer.trac.reporter.activate_reporter);
