cluetimer.trac = {
    init: function() {
        dojo.addClass(dojo.body(), 'claro');
    }
};

dojo.addOnLoad(cluetimer.trac.init);
