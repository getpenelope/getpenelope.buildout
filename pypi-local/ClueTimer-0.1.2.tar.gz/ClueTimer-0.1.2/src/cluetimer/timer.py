import datetime

_marker = object()


class Interval(object):
    """A simple time interval."""

    intervalid = None
    date = None
    userid = None
    hours = 0
    taskid = None
    summary = None

    def __init__(self, userid=None, date=None,
                 hours=None, taskid=None, summary=u''):
        self.userid = userid
        self.date = date
        self.hours = hours
        self.taskid = taskid
        self.summary = summary

    def __str__(self):
        return '<%s hours=%s>' % (self.__class__.__name__, self.hours)
    __repr__ = __str__


class IntervalDataStore(object):
    """A simple non-persistent datastore implementation for dealing with
    time intervals.

      >>> datastore = IntervalDataStore()
      >>> dt = datetime.date(2004, 03, 04)
      >>> datastore.save_interval(Interval('foo', dt, 4, 'abc'))
      >>> [x for x in datastore.load_intervals(dt, dt, 'foo')]
      [<Interval hours=4>]
      >>> [x for x in datastore.load_intervals(dt, dt, 'bar')]
      []
    """

    interval_factory = Interval

    def __init__(self):
        self._intervals = {}

    def save_interval(self, interval):
        assert interval.taskid is not None
        assert interval.hours is not None
        assert interval.userid is not None

        if getattr(interval, 'intervalid', None) is None:
            interval.intervalid = str(len(self._intervals) + 1)
        else:
            del self._intervals_by_intervalid[interval.intervalid]
        self._intervals[interval.intervalid] = interval

    def load_intervals(self, startdate, enddate=None,
                       userid=None, taskid=None):
        for x in self._intervals.values():
            if userid and userid != x.userid:
                continue
            if x.date >= startdate and \
                   (enddate is None or x.date <= enddate):
                yield x

    def load_interval(self, intervalid):
        return self._intervals[intervalid]


class IntervalGroup(object):

    def __init__(self):
        self.intervals = []

    @property
    def total_hours(self):
        total = 0
        for x in self.intervals:
            total += x.hours
        return total


class DailyIntervalGroup(dict, IntervalGroup):

    @property
    def intervals(self):
        for x in self.values():
            for y in x:
                yield y

    @property
    def total_hours(self):
        total = 0
        for x in self.values():
            total += x.total_hours
        return total

    def keys(self):
        keys = dict.keys(self)
        keys.sort()
        return keys

    def values(self):
        values = []
        for x in self.keys():
            values.append(self[x])
        return values

    def items(self):
        items = []
        for x in self.keys():
            items.append((x, self[x]))
        return items


class TimeManager(object):
    """A higher-level model for dealing with time.

      >>> tm = TimeManager()
      >>> tm.add_interval('foo', datetime.date(2008, 06, 03), 2, 'abc')
      <Interval hours=2>
      >>> [x for x in tm.get_intervals(startdate=datetime.date(2008, 06, 03))]
      [<Interval hours=2>]
    """

    def __init__(self, datastore=None):
        if datastore is None:
            datastore = IntervalDataStore()
        self.datastore = datastore

    def get_intervals(self, userid=None, startdate=None, enddate=None,
                      taskid=None):
        return self.datastore.load_intervals(startdate, enddate, userid,
                                             taskid)

    def get_daily_intervals(self, userid=None, startdate=None, enddate=None,
                            fill_empty_days=False):

        # make sure we weren't fed datetime's instead
        startdate = datetime.date(startdate.year,
                                  startdate.month, startdate.day)
        enddate = datetime.date(enddate.year,
                                enddate.month, enddate.day)

        days = DailyIntervalGroup()
        for x in self.get_intervals(userid, startdate, enddate):
            day = days.get(x.date, None)
            if day is None:
                day = days[x.date] = IntervalGroup()
            day.intervals.append(x)

        if fill_empty_days:
            one = datetime.timedelta(days=1)
            cur = startdate
            while cur < enddate:
                day = days.get(cur, None)
                if day is None:
                    days[cur] = IntervalGroup()
                cur += one

        return days

    def add_interval(self, userid, date, hours, taskid=None, summary=u''):
        f = self.datastore.interval_factory
        interval = f(userid, date, hours, taskid, summary)
        self.datastore.save_interval(interval)
        return interval

    def remove_interval(self, intervalid):
        self.datastore.del_interval(intervalid)

    def update_interval(self, intervalid, date=_marker, hours=_marker,
                        taskid=_marker, summary=_marker):

        interval = self.datastore.load_interval(intervalid)
        if date is not _marker:
            interval.date = date
        if hours is not _marker:
            interval.hours = hours
        if taskid is not _marker:
            interval.taskid = taskid
        if summary is not _marker:
            interval.summary = summary

        self.datastore.save_interval(interval)
        return interval

    def get_total_time(self, taskid=None, userid=None, startdate=None,
                       enddate=None):
        total = 0
        for x in self.get_intervals(userid, startdate, enddate, taskid):
            total += x.hours
        return total
