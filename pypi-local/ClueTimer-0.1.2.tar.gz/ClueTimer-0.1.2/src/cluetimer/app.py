from cluetimer import utils
from cluetimer.web import settings
from django.core.handlers import wsgi
from django.core.management import setup_environ
import optparse
import sqlalchemy as sa
import sys
from wsgiref import simple_server


def main(cmdargs=None):

    if cmdargs is None:
        cmdargs = sys.argv[1:]

    parser = optparse.OptionParser()
    parser.add_option('-a', '--address', dest='address',
                      default='0.0.0.0',
                      help='Address to listen on (by default it is '
                           '0.0.0.0 which is shorthand for all interfaces)')
    parser.add_option('-p', '--port', dest='port',
                      default='8080',
                      help='Port to listen on (by default 8080)')
    parser.add_option('-u', '--db-uri',
                      default='sqlite:///cluetimer.db',
                      dest='db_uri',
                      help='DB URI to connect to')
    (opts, args) = parser.parse_args(cmdargs)

    engine = sa.create_engine(opts.db_uri)

    app = wsgi.WSGIHandler()

    settings.TASK_DATASTORE = 'cluetimer.sqlmodel.SqlTaskDataStore'
    settings.TASK_DATASTORE_ARGS = [None, engine, True]
    settings.TIME_DATASTORE = 'cluetimer.sqlmodel.SqlIntervalDataStore'
    settings.TIME_DATASTORE_ARGS = [None, engine, True]
    setup_environ(settings)

    server = simple_server.make_server(opts.address,
                                       int(opts.port),
                                       app)

    logger = utils.setup_logger()
    logger.info("ClueTimer now listening on %s:%s"
                % (opts.address, opts.port))
    server.serve_forever()

    return 0

if __name__ == '__main__':
    sys.exit(main())
