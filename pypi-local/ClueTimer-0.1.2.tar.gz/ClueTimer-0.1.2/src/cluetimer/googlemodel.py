from google.appengine.ext import db
from cluetimer import tasker
from cluetimer import timer


class GoogleTask(db.Model, tasker.Task):
    userid = db.StringProperty(required=True)
    name = db.StringProperty(required=True)
    summary = db.StringProperty()
    estimate = db.FloatProperty(required=False)

    @property
    def taskid(self):
        return self.key().id()

    @staticmethod
    def kind():
        return 'Task'


class GoogleInterval(db.Model, timer.Interval):
    date = db.DateTimeProperty(required=True)
    userid = db.StringProperty(required=True)
    hours = db.FloatProperty(required=True, default=0.0)
    taskid = db.StringProperty(required=True)
    summary = db.StringProperty()

    @property
    def intervalid(self):
        return self.key().id()

    @staticmethod
    def kind():
        return 'Interval'


class GoogleTaskDataStore(tasker.TaskDataStore):

    task_factory = GoogleTask

    def save_task(self, t):
        t.put()

    def load_task(self, taskid):
        tasks = GoogleTask.gql('WHERE taskid = :1', taskid)
        if len(tasks) == 0:
            return None

        assert len(tasks) < 2
        return tasks[0]

    def load_tasks(self, userid=None):
        tasks = GoogleTask.all()
        return tasks


class GoogleIntervalDataStore(timer.IntervalDataStore):

    interval_factory = GoogleInterval

    def save_interval(self, interval):
        interval.put()

    def load_intervals(self, startdate, enddate, userid=None):
        return GoogleInterval.all()
