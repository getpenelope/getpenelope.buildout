class Task(object):
    """A simple task object."""

    userid = None
    taskid = None
    name = None
    summary = None
    estimate = None

    def __str__(self):
        return '<%s taskid=%s>' % (self.__class__.__name__, self.taskid)
    __repr__ = __str__


class TaskDataStore(object):
    """A simple non-persistent datastore implementation for dealing with
    tasks.

      >>> datastore = TaskDataStore()
      >>> datastore.save_task(Task())
      >>> [x for x in datastore.load_tasks()]
      [<Task taskid=1>]
      >>> datastore.load_task('1')
      <Task taskid=1>
    """

    task_factory = Task

    def __init__(self):
        self._tasks = {}

    def save_task(self, task):
        if getattr(task, 'taskid', None) is None:
            task.taskid = str(len(self._tasks) + 1)
        else:
            del self._tasks[task.taskid]
        self._tasks[task.taskid] = task

    def load_task(self, taskid):
        return self._tasks[taskid]

    def load_tasks(self, userid=None):
        for x in self._tasks.values():
            if userid and x.userid != userid:
                continue
            yield x


class TaskManager(object):
    """A higher-level model for dealing with tasks.

      >>> tm = TaskManager()
      >>> tm.add_task('somebody', u'Foo Bar', u'Random Description')
      <Task taskid=1>
      >>> task = tm.get_task('1')
      >>> (task.taskid, task.name, task.summary)
      ('1', u'Foo Bar', u'Random Description')
      >>> [x for x in tm.get_tasks()]
      [<Task taskid=1>]
    """

    def __init__(self, datastore=None):
        if datastore is None:
            datastore = TaskDataStore()
        self.datastore = datastore

    def add_task(self, userid, name, summary=u''):
        assert userid
        assert name

        task = self.datastore.task_factory()
        task.userid = userid
        task.name = name
        task.summary = summary
        self.datastore.save_task(task)
        return task

    def get_task(self, taskid):
        return self.datastore.load_task(taskid)

    def get_tasks(self, userid=None):
        return self.datastore.load_tasks(userid)
