jQuery(document).ready(function($) {
    setTimeout(TracWysiwyg.initialize, 10);
});
