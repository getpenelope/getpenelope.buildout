This module provide a set of utilities for using FormAlchemy_ with Pyramid

.. _formalchemy: http://docs.formalchemy.org/

Have a look at the `Online demo
<http://docs.formalchemy.org/demo/admin/>`_
or at the `Documentation
<http://docs.formalchemy.org/pyramid_formalchemy/>`_

Bug and feature request must be reported on the `github tracker
<https://github.com/FormAlchemy/pyramid_formalchemy/issues>`_




