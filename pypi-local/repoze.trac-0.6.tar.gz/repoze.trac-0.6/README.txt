A readme file.
