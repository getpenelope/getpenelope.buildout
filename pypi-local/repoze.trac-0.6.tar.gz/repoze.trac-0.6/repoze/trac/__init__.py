import optparse
import os
import os.path
import re
import sys

from trac.web.main import dispatch_request

class TracApp:
    def __init__(self, environkw, remote_user_header,
                 dispatch_request=dispatch_request):
        self.environkw = environkw
        self.remote_user_header = remote_user_header
        self.dispatch_request = dispatch_request

    def __call__(self, environ, start_response):
        if (not environ.has_key('REMOTE_USER')) and self.remote_user_header:
            remote_user = environ.get(self.remote_user_header)
            if remote_user:
                environ['REMOTE_USER'] = remote_user
        for k, v in self.environkw.items():
            environ[k] = v
        return self.dispatch_request(environ, start_response)

def make_trac(global_config, **kw):
    path = kw.get('env_path', None)
    if path is None:
        raise ValueError('"env_path=" required for make_trac setup')

    environkw = {}
    remote_user_header = None
    for k, v in kw.items():
        if k == 'remote_user_header':
            remote_user_header = v
        else:
            environkw['trac.'+k] = v
        
    return TracApp(environkw, remote_user_header)

here = os.path.abspath(os.path.dirname(__file__))

# I would use string.Template, but it's just too hard to change it to
# respect only ${brace} syntax instead of both that and $name syntax.
TOKEN_RE = re.compile(r'\$\{([\.\w/-]+)\}')
def rewrite(repltext, **kw):
    def replace(match):
        return kw[match.group(1)]
    return TOKEN_RE.sub(replace, repltext)

def make_instance(sandbox=None):
    if sandbox is None:
        sandbox = sys.prefix
        
    for dir in ('etc', 'var'):
        path = os.path.join(sandbox, dir)
        if not os.path.exists(path):
            os.makedirs(path)

    for source, target in (
        ('paste.ini', 'paste.ini'),
        ):
        template = open(os.path.join(here, 'etc', source), 'r').read()
        result = rewrite(template, sandbox=sandbox)
        targetfile = os.path.join(sandbox, 'etc', target)
        if not os.path.exists(targetfile):
            open(targetfile, 'w').write(result)

def trac_auth_challenge_decider(environ, status, headers):
    if environ['PATH_INFO'] == '/login':
        return True
    from repoze.pam.classifiers import default_challenge_decider
    return default_challenge_decider(environ, status, headers)

def main(argv=sys.argv):
    """ Console script target """
    parser = optparse.OptionParser(
        usage='%prog [PATH]'
        )
    options, args = parser.parse_args(sys.argv)
    if len(args) != 2:
        parser.print_help(sys.stderr)
        sys.exit(1)
    path = os.path.realpath(args[1])
    make_instance(path)
