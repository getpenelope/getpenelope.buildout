import unittest

class TestMakeTrac(unittest.TestCase):
    def _getFUT(self):
        from repoze.trac import make_trac
        return make_trac

    def test_no_env_path(self):
        f = self._getFUT()
        self.assertRaises(ValueError, f, None)

    def test_other(self):
        f = self._getFUT()
        result = f(None, env_path='foo', remote_user_header='bar', dummy='yup')
        self.assertEqual(result.environkw, {'trac.env_path':'foo',
                                            'trac.dummy':'yup'})
        self.assertEqual(result.remote_user_header, 'bar')

class TestTracApp(unittest.TestCase):
    def _getTargetClass(self):
        from repoze.trac import TracApp
        return TracApp

    def _makeOne(self, environkw, remote_user_header, dispatch):
        return self._getTargetClass()(environkw, remote_user_header, dispatch)

    def test_call_with_remoteuser(self):
        next = DummyApp()
        app = self._makeOne({}, 'ru_header', next)
        environ = {'REMOTE_USER':'fred', 'ru_header':'otherguy'}
        app(environ, None)
        self.assertEqual(environ['REMOTE_USER'], 'fred')

    def test_call_noremote_user_with_header_in_environ_no_option(self):
        next = DummyApp()
        app = self._makeOne({}, None, next)
        environ = {'ru_header':'otherguy'}
        app(environ, None)
        self.failIf('REMOTE_USER' in environ)

    def test_call_remote_user_with_header_in_environ_with_option(self):
        next = DummyApp()
        app = self._makeOne({}, 'ru_header', next)
        environ = {'REMOTE_USER':'fred', 'ru_header':'otherguy'}
        app(environ, None)
        self.assertEqual(environ['REMOTE_USER'], 'fred')

    def test_call_noremote_user_with_header_in_environ_with_option(self):
        next = DummyApp()
        app = self._makeOne({}, 'ru_header', next)
        environ = {'ru_header':'otherguy'}
        app(environ, None)
        self.assertEqual(environ['REMOTE_USER'], 'otherguy')

    def test_app_called_with_values(self):
        next = DummyApp()
        app = self._makeOne({'trac.biz':'baz'}, 'ru_header', next)
        environ = {}
        app(environ, None)
        self.assertEqual(environ['trac.biz'], 'baz')

class DummyApp:
    def __call__(self, environ, start_response):
        self.environ = environ
        self.start_response = start_response
        
         
        
